<?php 

    $db = mysqli_connect("localhost", "root", "", "webdev") or die("Connectivity Failed");

?>