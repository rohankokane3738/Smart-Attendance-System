<?php 

    $db = mysqli_connect("localhost", "root", "", "att") or die("Connectivity Failed");

?>